import React, { useState } from "react";
import {
    HStack,
    Button,
    Icon,
    Link,
    Tag,
    TagLabel,
    TagCloseButton,
    WrapItem,
    Wrap,
} from "@chakra-ui/react";
import { IoOptionsOutline } from "react-icons/io5";
import FilterModal from "./Filter";
import { Flex } from "@chakra-ui/react";
import { Link as RouterLink } from "react-router-dom";
import GridImage from "../../../Assets/Images/Camera-View/Grid.svg";
import DateTimePicker from "./DateTimePicker"
import ListImage from "../../../Assets/Images/Camera-View/List.svg";

const TagFilterComponent = ({ viewType }) => {
    const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
    const [selectedEvents, setSelectedEvents] = useState([]);
    const [selectedCameras, setSelectedCameras] = useState([]);
    const [activeComponent, setActiveComponent] = useState("grid");

    // Function to open the FilterModal
    const openFilterModal = () => {
        console.log("Filter Modal Opened");
        setIsFilterModalOpen(true);
    };

    // Function to close the FilterModal
    const closeFilterModal = () => {
        setIsFilterModalOpen(false);
    };

    // Function to handle applied filters from FilterModal
    const handleApplyFilters = (cameras, events) => {
        setSelectedCameras(cameras);
        setSelectedEvents(events);
        closeFilterModal();
    };

    const clearAllTags = () => {
        setSelectedCameras([]);
        setSelectedEvents([]);
    };

    return (
        <>
            <HStack spacing={4} mt={4}>
                <Button
                    leftIcon={<Icon as={IoOptionsOutline} />}
                    colorScheme="purple"
                    backgroundColor="#9234EA"
                    size="sm"
                    borderRadius="md"
                    onClick={openFilterModal}
                >
                    Filters
                </Button>

                <Link color="#9234EA" fontSize="sm" onClick={clearAllTags}>
                    Clear all
                </Link>
            </HStack>

            <Flex justifyContent={"space-between"} alignItems="center" mt={4}>
                <HStack spacing={4} mt={4}>
                    <Wrap spacing={4} mt={4} maxWidth="60%">
                        {selectedCameras.map((camera) => (
                            <WrapItem key={camera}>
                                <Tag size="lg" variant="outline">
                                    <TagLabel>{camera}</TagLabel>
                                    <TagCloseButton
                                        onClick={() =>
                                            setSelectedCameras(
                                                selectedCameras.filter((c) => c !== camera)
                                            )
                                        }
                                    />
                                </Tag>
                            </WrapItem>
                        ))}

                        {selectedEvents.map((event) => (
                            <WrapItem key={event}>
                                <Tag size="lg" variant="outline">
                                    <TagLabel>{event}</TagLabel>
                                    <TagCloseButton
                                        onClick={() =>
                                            setSelectedEvents(
                                                selectedEvents.filter((e) => e !== event)
                                            )
                                        }
                                    />
                                </Tag>
                            </WrapItem>
                        ))}
                    </Wrap>

                    <FilterModal
                        isOpen={isFilterModalOpen}
                        onClose={closeFilterModal}
                        selectedCameras={selectedCameras}
                        setSelectedCameras={setSelectedCameras}
                        selectedEvents={selectedEvents}
                        setSelectedEvents={setSelectedEvents}
                        onApply={handleApplyFilters}
                    />
                </HStack>

                <HStack>
                    <DateTimePicker />
                </HStack>

            </Flex>
        </>
    );
};

export default TagFilterComponent;