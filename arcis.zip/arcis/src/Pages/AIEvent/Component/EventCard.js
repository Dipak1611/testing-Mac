import React from "react";
import { Box, Image, Badge, Text, IconButton, HStack } from "@chakra-ui/react";
import { TimeIcon } from "@chakra-ui/icons";
import { FiMoreVertical } from 'react-icons/fi'; // Icon for the 3 vertical dots

const EventCard = () => {
  return (
    <Box
      maxW="sm"
      borderWidth="1px"
      borderRadius="lg"
      overflow="hidden"
      bg="gray.100"
      boxShadow="md"
    >
      {/* Top Badge */}
      <Badge
        colorScheme="cyan"
        variant="solid"
        position="absolute"
        top="10px"
        left="10px"
        px={2}
        py={1}
        borderRadius="md"
      >
        Edge Event
      </Badge>

      {/* Image Section */}
      <Image
        src="https://via.placeholder.com/300x200" // Replace this with the actual image source
        alt="Event Image"
        objectFit="cover"
        w="100%"
        h="150px"
      />

      {/* Bottom Card Content */}
      <Box p={4} bg="purple.100" position="relative">
        {/* Title */}
        <Text fontWeight="bold" fontSize="md" mb={1}>
          Entry Gate No 11
        </Text>

        {/* Date, Time, Duration */}
        <HStack justifyContent="space-between" alignItems="center">
          <Text fontSize="sm" color="gray.600">
            24/09/2024 &nbsp; 03:50 AM
          </Text>
          <Text fontSize="sm" color="gray.600">
            Duration: 10 min 30 sec
          </Text>
        </HStack>

        {/* Play Button and More Options */}
        <HStack justifyContent="space-between" alignItems="center" mt={3}>
          {/* Play Icon */}
          <IconButton
            icon={<TimeIcon />}
            aria-label="Play Video"
            size="sm"
            colorScheme="purple"
          />

          {/* More options icon (3 dots) */}
          <IconButton
            icon={<FiMoreVertical />}
            aria-label="More Options"
            size="sm"
            variant="ghost"
          />
        </HStack>
      </Box>
    </Box>
  );
};

export default EventCard;
