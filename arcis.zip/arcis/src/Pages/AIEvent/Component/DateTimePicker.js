// import React, { useState } from 'react';
// import { ChakraProvider, Box, Text, IconButton, HStack, Button, Input } from "@chakra-ui/react";
// import { ArrowLeftIcon, ArrowRightIcon, TimeIcon } from '@chakra-ui/icons';

// const DateTimePicker = () => {
//   const [selectedDate, setSelectedDate] = useState(13); // default selected date
//   const [fromTime, setFromTime] = useState('07:00');
//   const [toTime, setToTime] = useState('20:00');

//   // Array of weekdays
//   const days = [
//     { id: 12, label: "Mo" },
//     { id: 13, label: "Tu" },
//     { id: 14, label: "We" },
//     { id: 15, label: "Th" },
//     { id: 16, label: "Fr" },
//     { id: 17, label: "Sa" },
//     { id: 18, label: "Su" }
//   ];

//   // Function to change the selected date
//   const handleDateChange = (dayId) => {
//     setSelectedDate(dayId);
//   };

//   return (
//     <ChakraProvider>
//       <Box p={5} maxWidth="400px" borderWidth="1px" borderRadius="lg">
//         <Text>Select Date</Text>
//         <HStack spacing={2} justify="center" my={4}>
//           <IconButton
//             icon={<ArrowLeftIcon />}
//             onClick={() => handleDateChange(selectedDate - 1)}
//             isDisabled={selectedDate <= 12} // Disable for first day
//           />
//           {days.map(day => (
//             <Button
//               key={day.id}
//               colorScheme={selectedDate === day.id ? "purple" : "gray"}
//               onClick={() => handleDateChange(day.id)}
//             >
//               {day.label} {day.id}
//             </Button>
//           ))}
//           <IconButton
//             icon={<ArrowRightIcon />}
//             onClick={() => handleDateChange(selectedDate + 1)}
//             isDisabled={selectedDate >= 18} // Disable for last day
//           />
//         </HStack>

//         <Text>From</Text>
//         <Input
//           type="time"
//           value={fromTime}
//           onChange={(e) => setFromTime(e.target.value)}
//           mb={3}
//         />

//         <Text>To</Text>
//         <Input
//           type="time"
//           value={toTime}
//           onChange={(e) => setToTime(e.target.value)}
//         />
//       </Box>
//     </ChakraProvider>
//   );
// };

// export default DateTimePicker;






















import { Box, HStack, Button, Text, Input } from "@chakra-ui/react";
import { ChevronLeftIcon, ChevronRightIcon, TimeIcon } from "@chakra-ui/icons";
import { useState } from "react";
import dayjs from "dayjs"; // To manage dates

const AIEvent = () => {
    const [selectedDate, setSelectedDate] = useState(dayjs());
    const [fromTime, setFromTime] = useState("07:00");
    const [toTime, setToTime] = useState("20:00");

    const formatDate = (date) => date.format("ddd DD");

    // Handle previous and next navigation for dates
    const goToPreviousWeek = () => {
        setSelectedDate(selectedDate.subtract(1, "week"));
    };

    const goToNextWeek = () => {
        setSelectedDate(selectedDate.add(1, "week"));
    };

    const handleFromTimeChange = (e) => setFromTime(e.target.value);
    const handleToTimeChange = (e) => setToTime(e.target.value);

    const daysOfWeek = Array.from({ length: 7 }, (_, index) =>
        selectedDate.startOf("week").add(index, "day")
    );
    return (
        <>
            <Box p={5} maxW="400px" borderRadius="md" boxShadow="md">
                <Text mb={2}>Select Date</Text>
                <HStack spacing={2}>
                    <Button size="sm" variant="ghost" onClick={goToPreviousWeek}>
                        <ChevronLeftIcon />
                    </Button>
                    {daysOfWeek.map((date) => (
                        <Button
                            key={date}
                            size="sm"
                            variant={selectedDate.isSame(date, "day") ? "solid" : "ghost"}
                            bg={selectedDate.isSame(date, "day") ? "purple.300" : "transparent"}
                            onClick={() => setSelectedDate(date)}
                        >
                            {formatDate(date)}
                        </Button>
                    ))}
                    <Button size="sm" variant="ghost" onClick={goToNextWeek}>
                        <ChevronRightIcon />
                    </Button>
                </HStack>

                <HStack mt={4} spacing={4}>
                    <Box>
                        <Text mb={1}>From</Text>
                        <HStack>
                            <Input
                                size="sm"
                                value={fromTime}
                                onChange={handleFromTimeChange}
                                type="time"
                            />
                            <TimeIcon color="purple.300" />
                        </HStack>
                    </Box>

                    <Box>
                        <Text mb={1}>To</Text>
                        <HStack>
                            <Input
                                size="sm"
                                value={toTime}
                                onChange={handleToTimeChange}
                                type="time"
                            />
                            <TimeIcon color="purple.300" />
                        </HStack>
                    </Box>
                </HStack>
            </Box>


        </>
    )
}

export default AIEvent
