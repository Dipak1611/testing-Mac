import {
    Tabs,
    TabList,
    Tab
} from "@chakra-ui/react";

const Header = () => {

    return (
        <Tabs variant="unstyled" defaultIndex={0}>
            <TabList backgroundColor="#D8B4FE" borderRadius="10px" width="600px">
                <Tab
                    width="200px"
                    borderRadius="10px"
                    _selected={{ color: "white", backgroundColor: "#9234EA" }}
                    _hover={{ bg: "purple.600" }}
                >
                    My Cameras
                </Tab>
                <Tab
                    width="200px"
                    borderRadius="10px"
                    _selected={{ color: "white", backgroundColor: "#9234EA" }}
                    _hover={{ bg: "purple.600" }}
                >
                    Shared Cameras
                </Tab>
                <Tab
                    width="200px"
                    borderRadius="10px"
                    borderLeftColor={"black"}
                    borderLeftWidth={2}
                    _selected={{ color: "white", backgroundColor: "#9234EA" }}
                    _hover={{ bg: "purple.600" }}
                >
                    Notification
                </Tab>
            </TabList>
        </Tabs>
    );
};

export default Header;