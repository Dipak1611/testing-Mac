import React from "react";
import Header from "./Component/Header";
import { Text } from "@chakra-ui/react";
import FilterBar from "./Component/FilterBar"
import EventCard from "./Component/EventCard"
import { Flex } from "@chakra-ui/react";

const AIEvent = () => {
    return (
        <>
        <Flex justifyContent={"space-around"} flexDirection={"column"}>
            <Header />
            <Text>
                AIEvent
                <Text>
                    List of events triggered by the camera
                </Text>
            </Text>
            <FilterBar />
                

                <EventCard />
                <EventCard />
                <EventCard />
                <EventCard />
                </Flex>
        </>
    );
};

export default AIEvent;








