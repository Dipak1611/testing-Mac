import React from 'react';
import CameraNavigation from './CameraNavigation';
import SearchArchives from './SearchArchieves';
import VideoPlayer from './VideoPlayer';
import PlaybackControls from './PlaybackControl';

const CameraView = () => {
    return (
        <div>
            <CameraNavigation />
            <div style={{ display: 'flex', gap: '20px' }}>
                <SearchArchives />
                <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                    <VideoPlayer />
                    <PlaybackControls />
                </div>
            </div>
        </div>
    );
};

export default CameraView;