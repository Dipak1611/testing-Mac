import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, Button, Flex, Spacer} from "@chakra-ui/react";
import { ChevronRightIcon } from '@chakra-ui/icons';
import { FaArrowLeft } from 'react-icons/fa';

function CameraNavigation() {
    return (
        <Flex pb={4} pr={4} alignItems="center" flexDir={'column'} width={'100%'}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent:"space-between", width: '100%' }}>
                {/* Breadcrumb Navigation */}
                <Breadcrumb spacing="8px" separator={<ChevronRightIcon color="gray.500" />}>
                    <BreadcrumbItem>
                        <BreadcrumbLink href="#">Camera</BreadcrumbLink>
                    </BreadcrumbItem>

                    <BreadcrumbItem>
                        <BreadcrumbLink href="#">Grouping</BreadcrumbLink>
                    </BreadcrumbItem>

                    <BreadcrumbItem isCurrentPage>
                        <BreadcrumbLink href="#">Entry gate no. 11</BreadcrumbLink>
                    </BreadcrumbItem>
                </Breadcrumb>

                <Spacer />

                {/* Back Button */}
                <Button leftIcon={<FaArrowLeft />} variant="link" colorScheme="blackAlpha" size="sm">
                    Back
                </Button>
            </div>



            {/* Next Device */}
            <Button variant="link" colorScheme="blackAlpha" size="sm">
                Next Device
            </Button>
        </Flex>
    );
}

export default CameraNavigation;