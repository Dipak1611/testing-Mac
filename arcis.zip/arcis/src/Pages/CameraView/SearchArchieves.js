import { Box, Button, Input, Flex, Stack, Text, Image, Heading } from "@chakra-ui/react";

import DatePicker from 'react-datepicker';
import React, { useState } from "react";
import { InputGroup, InputRightElement } from "@chakra-ui/react";

function SearchArchives() {
    const [startDate, setStartDate] = useState(new Date());
    return (
        <Box p={3} boxShadow="1px 2px 20px 1px rgba(0, 0, 0, 0.25)" borderRadius="lg" bg="#fcfcfc" width="350px" height={"743px"}>
            {/* Header */}
            <Heading as="h2" mt={1} size="md" textAlign="center" color={'#141e35'} mb={3.5}>
                Search Archives
            </Heading>

            {/* Date Picker and Time Inputs */}
            <Stack spacing={4}>
                {/* Select Date */}
                <Flex alignItems="center" justifyContent={"left"} textAlign={"left"} flexDirection={"column"}>
                    <Text textAlign={"left"}>Select Date</Text>
                    <Flex flex={1} width="100%" justify="flex-end">
                        {/* InputGroup to handle the input and icon */}
                        <InputGroup size="sm">
                            {/* Input field */}
                            <Input width={"100%"}
                                id="dateInput"
                                type="text"
                                value={startDate ? startDate.toLocaleDateString() : ''}
                                readOnly
                            />

                            {/* DatePicker inside InputRightElement */}
                            <InputRightElement width="3rem" zIndex={10}>
                                <DatePicker
                                    //   zIndex={1}

                                    selected={startDate}
                                    onChange={(date) => setStartDate(date)}
                                    dateFormat="dd/MM/yyyy"
                                    maxDate={new Date()} // Restrict future dates
                                    customInput={
                                        <img
                                            src="https://cdn.builder.io/api/v1/image/assets/TEMP/d9e379764ccd420a9ec9980469d463bb5e4bbf54cb46fe0d89ba51f45961ae23?placeholderIfAbsent=true&apiKey=5e6c7542e7f24225a4d3d5a1be551cbc"
                                            alt="Calendar"
                                            height="15px"
                                            onClick={() => document.getElementById('dateInput').focus()}
                                            style={{ cursor: 'pointer' }} // Pointer cursor on hover
                                        />
                                    }
                                />
                            </InputRightElement>
                        </InputGroup>
                    </Flex>
                </Flex>

                <Flex width="100%" justifyContent={"space-between"} textAlign={"left"}>
                    {/* From Time */}
                    <Flex alignItems="center" flexDirection={"column"} width={"50%"} justifyContent={"left"}>
                        <Text justifyContent={'left'} textAlign={'left'}>From</Text>
                        <Flex flex={1} justify="flex-end">
                            <Input type="time" defaultValue="09:00" size="sm" />
                        </Flex>
                    </Flex>

                    {/* To Time */}
                    <Flex alignItems="center" flexDirection={"column"}>
                        <Text>To</Text>
                        <Flex flex={1} justify="flex-end">
                            <Input type="time" defaultValue="16:00" size="sm" />
                        </Flex>
                    </Flex>
                </Flex>

                {/* Find Recording Button */}
                <Button colorScheme="purple" width="100%" mt={4}>
                    Find Recording
                </Button>
            </Stack>

            {/* Archive Thumbnails */}
            <Box mt={6} height={'450px'} overflowY={'scroll'}>
                {Array(7).fill(0).map((_, index) => (
                    <Flex key={index} mb={4} alignItems="center">
                        <Image
                            boxSize="60px"
                            objectFit="cover"
                            src="https://via.placeholder.com/60"
                            alt="Archive Thumbnail"
                            mr={4}
                            borderRadius="md"
                        />
                        <Box flex={1}>
                            <Text fontSize="sm">Entry gate no.11</Text>
                            <Text fontSize="xs" color="gray.500">20/09/2024</Text>
                        </Box>
                        <Text fontSize="sm" color="gray.700">14:50</Text>
                    </Flex>
                ))}
            </Box>
        </Box>
    );
}

export default SearchArchives;
