import { Box, Flex, IconButton, Image, Text, Stack, Progress } from "@chakra-ui/react";
import { FaChevronUp, FaChevronDown, FaChevronLeft, FaChevronRight } from 'react-icons/fa';
import { IoIosInformation } from 'react-icons/io';
import { BsZoomIn } from "react-icons/bs";


function VideoPlayer() {
    return (
        <Box bg="gray.900" borderRadius="lg" overflow="hidden" position="relative" height="60vh" width="65vw">
            {/* Video Section */}
            <Image
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/acaf53afa3a368d56009edb8b54637eb8ca9742403b834cf2a816b047c5ebae0?placeholderIfAbsent=true&apiKey=5e6c7542e7f24225a4d3d5a1be551cbc" // Replace with video source or thumbnail
                alt="Video Stream"
                width="100%"
                height="100%"
                objectFit="cover"
            />

            <Flex position="absolute" alignItems={'end'} left={6} right={6} bottom={2}>
                {/* Overlay Controls (Left) */}
                <Stack spacing={4} alignItems="flex-start" zIndex={2}>

                    {/* Camera Info */}
                    <Box color="white">
                        <Text fontSize="12px" marginLeft={-2}>Entry gate no. 11</Text>
                        <Flex gap="12px" alignItems={"center"} >
                            <Text fontSize="12px" color="gray.300">20/09/2024</Text>
                            <Text fontSize="12px" color="gray.300">14:50</Text>
                        </Flex>
                    </Box>
                    {/* Play/Pause Button */}
                    {/* <IconButton
                        icon={<FaPlay />} 
                        colorScheme="whiteAlpha"
                        aria-label="Play/Pause"
                        isRound
                    /> */}
                    <Flex gap={2} alignItems={"center"} >
                        <BsZoomIn style={{ backgroundColor: "white", padding: "4px 5px", borderRadius: "7px", color: "black", fontSize: "28px" }} />
                        <IoIosInformation style={{ backgroundColor: "white", padding: "1px", borderRadius: "50%", color: "black", fontSize: "28px" }} boxSize={6} />
                    </Flex>
                </Stack>


                {/* Progress Bar (Bottom) */}
                <Box width={"100%"} pb={2}>
                    <Progress value={40} colorScheme="purple" height="2px" />
                </Box>


                {/* Vertical Controls (Right) */}
                <Stack
                    spacing={2}
                    zIndex={2}
                    direction="column"
                    alignItems="center"
                >
                    <div>
                        <IconButton icon={<FaChevronUp />} colorScheme="purple" isRound />
                    </div>
                    <Flex gap={"3.5rem"} alignItems={"center"}>
                        <IconButton icon={<FaChevronLeft />} colorScheme="purple" isRound />
                        <IconButton icon={<FaChevronRight />} colorScheme="purple" isRound />
                    </Flex>
                    <div>
                        <IconButton icon={<FaChevronDown />} colorScheme="purple" isRound />
                    </div>
                </Stack>
            </Flex>


            <Flex justifyContent={'space-between'} position='absolute' right={4} top={4} left={4} alignItems={'start'}>
                <Flex position="absolute" flexDirection="column" gap="5px" >
                    {['https://cdn.builder.io/api/v1/image/assets/TEMP/8333a9f69be2ac10cf3ca56707ba159e740e8620b0a3f29fd734cc466c69296c?placeholderIfAbsent=true&apiKey=5e6c7542e7f24225a4d3d5a1be551cbc',
                        'https://cdn.builder.io/api/v1/image/assets/TEMP/2e6955558d60f426a56273a40f026fe3c11857bdd53ae620724c298dc930cd85?placeholderIfAbsent=true&apiKey=5e6c7542e7f24225a4d3d5a1be551cbc',
                        'https://cdn.builder.io/api/v1/image/assets/TEMP/94d3433649268586da8b194e36ce67b48b5be085d7acf5b22f33cee566e6e3dd?placeholderIfAbsent=true&apiKey=5e6c7542e7f24225a4d3d5a1be551cbc',
                        'https://cdn.builder.io/api/v1/image/assets/TEMP/b8eb72b6d574f1e98e0efb211f9a6b2b0f4bc35f98d2c6d0e8fabf93951b9972?placeholderIfAbsent=true&apiKey=5e6c7542e7f24225a4d3d5a1be551cbc']
                        .map((src, index) => (
                            <IconButton
                                key={index}
                                borderBottomLeftRadius={0}
                                borderTopRightRadius={0}
                                icon={<img src={src} alt={`Control ${index + 1}`} style={{ width: '80%', height: 'auto' }} />}
                                colorScheme="white"
                                backgroundColor="white"
                                aria-label={`Control ${index + 1}`}
                                zIndex={2}
                            />
                        ))}
                </Flex>
                <Box position={'absolute'} right={0} >
                    <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/8cd8b85581cc0b3f37de43c5f5e99558bf418b8c52f805dc5a2bcb111cce9bf5?placeholderIfAbsent=true&apiKey=5e6c7542e7f24225a4d3d5a1be551cbc" alt="Camera controls" />
                </Box>
            </Flex>


        </Box>
    );
}

export default VideoPlayer;