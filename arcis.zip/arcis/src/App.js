import "./App.css";
import { Routes, Route, useLocation } from "react-router-dom";

// Component Folder
import Header from "./Components/Header/Header";
import SidebarMenu from "./Components/SidebarMenu/SidebarMenu";
import LoginPage from "./Components/LoginPage/LoginPage";
import SignUpPage from "./Components/SignUpPage/SignUpPage";
import OtpVerification from "./Components/OtpVerification/OtpVerification";
// Pages Folder
import CameraView from "./Pages/CameraView/CameraView";
import CameraGroup from "./Pages/CameraGroup/CameraGroup";
import AIEvent from "./Pages/AIEvent/AI-Event"

function App() {
    const location = useLocation();

    // Define the paths where Header and Sidebar should not render
    const noHeaderSidebarPaths = ["/signup", "/", "/otp"];
    const shouldShowHeaderAndSidebar = !noHeaderSidebarPaths.includes(location.pathname);

    return (
        <div className="App">
            {shouldShowHeaderAndSidebar && <Header />}
            <div style={{ display: "flex" }}>
                {shouldShowHeaderAndSidebar && <SidebarMenu />}
                <div className={`content ${shouldShowHeaderAndSidebar ? "with-sidebar" : ""}`}>
                    <Routes>
                        <Route path="/" element={<LoginPage />} />
                        <Route path="signup" element={<SignUpPage />} />
                        <Route path="/otp" element={<OtpVerification />} />
                        <Route path="/camera-group" element={<CameraGroup />} />
                        <Route path="/camera-view" element={<CameraView />} />
                        <Route path="/ai-events" element={<AIEvent />} />
                    </Routes>
                </div>
            </div>
        </div>
    );
}

export default App;